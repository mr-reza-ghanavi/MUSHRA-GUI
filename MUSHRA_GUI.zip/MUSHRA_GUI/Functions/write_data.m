function write_data(readme)

        writecell(readme,'Memory/trial_data.txt');
end